import os
import boto3
import pgpy
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# AWS Clients
secrets_client = boto3.client('secretsmanager')
ses_client = boto3.client('ses')
s3_client = boto3.client('s3')

# Environment Variables
PGP_KEY_SECRET = os.environ['PGP_KEY_SECRET']
PGP_PASSPHRASE_SECRET = os.environ['PGP_PASSPHRASE_SECRET']
EMAIL_SENDER = os.environ['EMAIL_SENDER']
EMAIL_RECIPIENT = os.environ['EMAIL_RECIPIENT']

def lambda_handler(event, context):
    print(f"Received event: {event}")

    # Extract bucket and key from Transfer Workflow event
    bucket = event['input']['fileLocation']['bucket']
    key = event['input']['fileLocation']['key']
    file_name = key.split('/')[-1]

    # Download encrypted file from S3
    encrypted_obj = s3_client.get_object(Bucket=bucket, Key=key)
    encrypted_data = encrypted_obj['Body'].read()

    # Fetch PGP key and passphrase from Secrets Manager
    private_key_data = secrets_client.get_secret_value(SecretId=PGP_KEY_SECRET)['SecretString']
    passphrase = secrets_client.get_secret_value(SecretId=PGP_PASSPHRASE_SECRET)['SecretString']

    # Load and unlock the PGP key
    private_key, _ = pgpy.PGPKey.from_blob(private_key_data)
    private_key.unlock(passphrase)

    # Decrypt file content
    encrypted_message = pgpy.PGPMessage.from_blob(encrypted_data)
    decrypted = private_key.decrypt(encrypted_message)
    decrypted_content = str(decrypted.message)

    print("Decrypted content preview:")
    print(decrypted_content[:200])  # Print first 200 chars for logs

    # Basic Validation
    if "EXPECTED_CONTENT" in decrypted_content:
        print("Validation Passed ✅")
        send_confirmation_email(file_name)
    else:
        print("Validation Failed ❌")
        raise Exception("File validation failed")

def send_confirmation_email(file_name):
    subject = "✅ File Received, Decrypted, and Validated"
    body = f"The file `{file_name}` was successfully received via SFTP, decrypted, and passed validation."

    # Compose Email
    msg = MIMEMultipart()
    msg['From'] = EMAIL_SENDER
    msg['To'] = EMAIL_RECIPIENT
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    # Send Email
    try:
        response = ses_client.send_raw_email(
            Source=EMAIL_SENDER,
            Destinations=[EMAIL_RECIPIENT],
            RawMessage={'Data': msg.as_string()}
        )
        print(f"Email sent: {response}")
    except Exception as e:
        print(f"Email failed: {e}")
        raise e
